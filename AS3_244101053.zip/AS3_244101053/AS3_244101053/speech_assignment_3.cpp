// speech_assignment_3.cpp : Defines the entry point for the console application.
//
/*** Since DC shift is zero in the system DC shift code is not included here
The values does not change with respect to Normalization so there is no need of normalization ***/
#include "stdafx.h"
#include "stdio.h"
#include "process.h"
#include <stdlib.h>
double arr[320 * 100];
double R[13];

void calculate_R(double *signal) {
	for(int i=0;i<=12;i++) {
		double sum = 0.0;
		for(int j = 0; j<320 && j+i<320;j++) {
			sum += signal[j] * signal[i+j];
		}
		R[i] = sum;
	}
}

void read_file(char *filename, int *length) {
	double x1,x;
	FILE *f1 = NULL;
	int err = fopen_s(&f1 , filename , "r");
	if (err !=NULL){
		printf( "\n Cannot Open");
		system("pause");
		exit(1);
	}
	int i = 0;
	while(!feof(f1)){
		if ( fscanf_s(f1 , "%lf" , &x) == 1){
			x1 = x;
			arr[i] = x1;
			i++;
		}
	}

	*length = i;
	fclose(f1);
}

void levinson_durbin(double *Ai) {
    double E[13];
	double Alpha[13][13];
	double k[13];

	E[0] = R[0];
	for(int i=1;i<=12;i++) {
		double sum = 0.0;

		for(int j=1;j<=i-1;j++) {
			sum += Alpha[i-1][j] * R[i-j];
		}

		k[i] = (R[i] - sum) / E[i-1];

		Alpha[i][i] =  k[i];

		for(int j=1;j<=i-1;j++) {
			Alpha[i][j] = Alpha[i-1][j] - k[i] * Alpha[i-1][i-j];
		}

		E[i] = (1 - k[i] * k[i]) * E[i-1];
	}

	for(int i=1;i<=12;i++) {
		Ai[i] = Alpha[12][i];
	}
}

void save_to_file(char *filename, double *Ai) {
	FILE *f1 = NULL;
	int err = fopen_s(&f1, filename, "a");
	if (err !=NULL){
		printf( "\n Cannot Open");
		system("pause");
		exit(1);
	}

	for(int i=1;i<=12;i++) {
		fprintf_s(f1, "%lf \t", Ai[i]);
	}
	fprintf(f1, "\n");

	fclose(f1);
}

void compute_steady_frames(int length, double frames[][320], int* num_frames) {
    double* energy = (double*)malloc((length / 320) * sizeof(double));
    int frame_index = 0;

    // Calculate energy for each frame
    for (int i = 0; i < length; i += 320) {
        energy[frame_index] = 0.0;
        for (int j = 0; j < 320; j++) {
            energy[frame_index] += arr[i + j] * arr[i + j];
        }
        frame_index++;
    }

    // Select steady frames based on energy threshold
    double threshold = 0.05 * energy[0];  // You can adjust this threshold
    *num_frames = 0;

    for (int i = 0; i < frame_index; i++) {
        if (energy[i] > threshold && *num_frames < 5) {
            for (int j = 0; j < 320; j++) {
                frames[*num_frames][j] = arr[i * 320 + j];
            }
            (*num_frames)++;
        }
    }
}

int _tmain(int argc, _TCHAR* argv[])
{
	char *inputfilename = "244101053_u_20.txt";
	char *outputfilename = "244101053_u_20_ai.txt";
	int length;

	read_file(inputfilename, &length);

	double steady[5][320];
	int num_frames;
	compute_steady_frames(length, steady, &num_frames);

	for(int i=0;i<num_frames;i++) {
		calculate_R(steady[i]);

		double *Ai = (double *)malloc(13 * sizeof(double));

		levinson_durbin(Ai);
		save_to_file(outputfilename, Ai);
	}

	return 0;	
}


