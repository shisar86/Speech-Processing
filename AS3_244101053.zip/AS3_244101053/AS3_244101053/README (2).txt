step 1: Record the audio of each vowel using Cooledit software.
step 2: Store the ASCII text of the audios recorded.
step 3: Feed the ASCII text of the audios file as the input. 
step 3: Then calculate the Ri values and Ai values using Durbin Levenson algorithm.
step 4: Print Ai values in a separate output file and store it in the same folder.